WEAK LADDER STRUCTURAL DIAGNOSTICS
==================================

Files
-----

weak_ladders_profiles.csv
weak_ladders_summary.csv


Purpose
-------

These files contain diagnostic outputs generated during UNNS chamber
analysis when spectral ladders are classified as structurally weak or
marginal.

The files do not represent raw spectral data. Instead, they store
analysis results describing how weak ladders behave during the
admissibility (κ) scan performed by the chamber.


Background
----------

During UNNS structural analysis, each spectral ladder is evaluated
across a range of κ parameters that control the admissibility scan.
This produces structural metrics describing how stable the ladder
remains under recursive perturbation.

Ladders are then classified into two broad categories:

    Strong ladders
        Stable structural signatures across κ.

    Weak ladders
        Marginal or unstable structural signatures that require
        additional diagnostics.

The files in this folder record those diagnostics.


File: weak_ladders_profiles.csv
-------------------------------

This file contains the full κ-scan profiles for ladders identified as
structurally weak.

Each row corresponds to a single κ evaluation for a given ladder.

Columns:

    ladder      — ladder identifier (index within the dataset)
    kappa       — κ parameter used in the admissibility scan
    nu          — recursion depth / vulnerability budget
    inv         — inversion ratio detected during the scan
    rho         — normalized instability metric
    Ak          — admissibility coefficient at the given κ

These rows together form a structural response curve:

    κ → Ak(κ), ρ(κ), inv(κ)

The profiles allow detailed inspection of how ladder stability evolves
across the admissibility parameter space.


File: weak_ladders_summary.csv
------------------------------

This file provides a compact statistical summary of the weak ladder
profiles.

Each row corresponds to one ladder.

Columns:

    file        — chamber result source file
    ladder      — ladder identifier
    n           — number of energy levels in the ladder
    mean_Ak     — average admissibility coefficient
    min_Ak      — minimum admissibility observed
    mean_rho    — average instability metric
    max_rho     — maximum instability observed

The summary file is used for rapid comparison of weak ladders across
datasets.


Role in the UNNS Analysis Pipeline
----------------------------------

These diagnostics are generated automatically during chamber execution
when weak ladders are detected.

They are used to:

    • identify structural phase boundaries
    • analyze instability regimes
    • study marginal spectral structures
    • compare structural behavior across domains

The weak ladder diagnostics complement the primary chamber outputs and
help reveal how structural stability varies between physical systems.


Notes
-----

These files are intermediate analysis artifacts.

They are not used as direct chamber inputs but serve as diagnostic data
supporting structural interpretation and cross-domain comparison within
the UNNS research program.
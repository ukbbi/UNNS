GOE Spectra Dataset
Random Matrix Eigenvalue Corpus for STRUCT-I Experiments
UNNS Substrate Program

---

## File

goe_spectra.csv

## Purpose

This dataset contains eigenvalue spectra generated from random symmetric
matrices drawn from the Gaussian Orthogonal Ensemble (GOE). It serves as
a synthetic control corpus for experiments performed with the STRUCT-I
chamber in the UNNS Substrate Program.

Unlike observational datasets (atomic spectra, solar activity ladders,
cosmic structure data, etc.), this dataset represents a purely random
matrix model with well-known statistical properties. It is therefore
useful as a baseline for testing whether structural persistence detected
by the chamber arises from real physical organization or from generic
random spectra.

## Generation Method

The dataset was generated using Python with NumPy according to the
following procedure:

1. Random matrices A are drawn with entries from a normal distribution:
   A ~ Normal(0,1)

2. A symmetric matrix is constructed:
   M = (A + Aᵀ) / 2

   This produces a matrix belonging to the Gaussian Orthogonal Ensemble.

3. The ordered eigenvalues of M are computed using:

   eigvals = numpy.linalg.eigvalsh(M)

4. Eigenvalues are sorted and written to the dataset together with the
   matrix identifier and matrix size.

## Matrix Sizes and Samples

Three matrix sizes were generated:

N = 100
N = 200
N = 500

For each size:

1000 independent matrices were sampled.

Total matrices generated:

3000 matrices

## Dataset Size

Total eigenvalues recorded:

1000 × 100  = 100,000
1000 × 200  = 200,000
1000 × 500  = 500,000
---------------------

Total       = 800,000 eigenvalues

## File Structure

The CSV file contains the following columns:

matrix_id
Identifier of the random matrix from which the eigenvalue was drawn.

index
Position of the eigenvalue within the sorted spectrum.

eigenvalue
Numerical value of the eigenvalue.

size
Dimension N of the matrix.

## Example Rows

matrix_id,index,eigenvalue,size
0,0,-20.73,500
0,1,-20.11,500
0,2,-19.82,500
...
1,0,-18.44,200
...

## Mathematical Background

Eigenvalues of GOE matrices follow universal statistical laws from
Random Matrix Theory.

Key properties include:

• Wigner semicircle eigenvalue density
• Level repulsion between adjacent eigenvalues
• Universal spacing statistics for chaotic systems

These properties make GOE spectra a standard model for complex quantum
systems and chaotic dynamics.

## Role in the UNNS Program

Within the UNNS Substrate research program this dataset is used as a
control experiment for STRUCT-I analysis.

Comparisons between GOE spectra and real observational datasets help
determine whether the admissibility inequality

```
inv(Pε; L) ≤ ν(Vε(L))
```

detects genuine structural organization in physical systems.

If GOE spectra behave differently from physical ladders (atomic spectra,
cosmic structures, solar plasma data, etc.), this provides evidence that
the chamber is responding to real structural constraints rather than to
random spectral behavior.

## Software Environment

Dataset generated using:

Python
NumPy
Pandas

## Author

Generated as part of the UNNS Substrate Program experimental corpus.

## License

This dataset is synthetic and may be freely used for research and
testing purposes.

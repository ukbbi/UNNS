import numpy as np
import pandas as pd

sizes = [100,200,500]
samples = 1000

rows = []

matrix_id = 0

for N in sizes:
    for s in range(samples):

        A = np.random.normal(size=(N,N))
        M = (A + A.T)/2     # GOE symmetric matrix

        eigvals = np.linalg.eigvalsh(M)
        eigvals.sort()

        for i,val in enumerate(eigvals):
            rows.append([matrix_id,i,val,N])

        matrix_id += 1

df = pd.DataFrame(rows,columns=[
    "matrix_id","index","eigenvalue","size"
])

df.to_csv("goe_spectra.csv",index=False)
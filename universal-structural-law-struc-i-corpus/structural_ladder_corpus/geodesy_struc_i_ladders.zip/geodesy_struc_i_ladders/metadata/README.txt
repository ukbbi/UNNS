
README.txt
Crustal Deformation STRUC-I Ladder Dataset
UNNS Substrate Program

Overview
This dataset contains ladder representations derived from GNSS station
time series measuring crustal deformation.

The original files are Nevada Geodetic Laboratory tenv3 station records.
Each station provides daily measurements of East, North, and Vertical
displacements.

For UNNS STRUC-I analysis these measurements were converted into
structural ladders using total displacement magnitude:

    d = sqrt(east^2 + north^2 + up^2)

All displacement magnitudes were sorted to form ladder levels.

Dataset Domain
family: geodesy
class: crustal_deformation

Files

CAC2_crustal_displacement_ladder.csv — displacement ladder derived from GNSS station
P579_crustal_displacement_ladder.csv — displacement ladder derived from GNSS station
P591_crustal_displacement_ladder.csv — displacement ladder derived from GNSS station
P811_crustal_displacement_ladder.csv — displacement ladder derived from GNSS station
P812_crustal_displacement_ladder.csv — displacement ladder derived from GNSS station

File Format

Each CSV file contains one column:

energy

Values represent ordered displacement magnitudes.

Conversion Procedure

1. Read east, north, and vertical displacement columns
2. Compute displacement magnitude
3. Remove missing values
4. Sort ascending
5. Export as ladder

Purpose

These ladders allow STRUC-I chambers to test admissibility geometry
within geophysical deformation systems.

UNNS Substrate Research Program
Chamber: STRUC-I

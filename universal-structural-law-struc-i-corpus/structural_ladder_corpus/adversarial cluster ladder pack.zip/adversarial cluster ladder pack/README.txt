Cluster Adversarial Ladder Pack (2000 points)

Files:
- uniform_baseline_ladder.csv
  Simple monotonic ladder x_i = i.

- single_cluster_ladder.csv
  One dense near-degenerate cluster embedded in otherwise regular spacing.

- multi_cluster_ladder.csv
  Multiple dense clusters at separated positions.

- microgap_ladder.csv
  Almost continuous ladder with extremely small gaps.

Purpose:
Stress-test STRUC-I by maximizing inversion pressure relative to gap-graph vulnerability.

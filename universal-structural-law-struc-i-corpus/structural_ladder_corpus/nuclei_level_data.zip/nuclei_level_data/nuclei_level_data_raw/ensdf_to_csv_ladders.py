import os
import csv

folder = "."
output = "nuclear_level_ladders.csv"

rows = []

for fname in os.listdir(folder):

    if not fname.startswith("ensdf_") or not fname.endswith(".txt"):
        continue

    nucleus = fname.replace("ensdf_","").replace(".txt","")

    energies = []

    with open(fname,"r",encoding="utf8") as f:

        for line in f:

            if " L " not in line:
                continue

            parts = line.split()

            if len(parts) < 3:
                continue

            try:
                energy = float(parts[2])
                energies.append(energy)
            except:
                pass


    energies = sorted(set(energies))

    for i,e in enumerate(energies):

        spacing = None
        if i > 0:
            spacing = e - energies[i-1]

        rows.append([nucleus,i,e,spacing])


with open(output,"w",newline="") as f:

    writer = csv.writer(f)
    writer.writerow(["nucleus","level_index","energy_keV","spacing_keV"])
    writer.writerows(rows)

print("CSV created:",output)
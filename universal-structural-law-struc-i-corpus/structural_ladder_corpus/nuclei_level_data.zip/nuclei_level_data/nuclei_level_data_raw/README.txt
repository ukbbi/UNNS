NUCLEAR LEVEL DATA — RAW ENSDF FILES
====================================

Folder name:
nuclei_level_data_raw


Purpose
-------

This folder contains raw nuclear level data extracted from ENSDF-style
( Evaluated Nuclear Structure Data File ) datasets for multiple nuclei.

The files store the original nuclear level information used to construct
energy-level ladders for the UNNS structural analysis of nuclear spectra.

These datasets are later converted into a unified CSV ladder format
used by the UNNS chamber analysis pipeline.


Contents
--------

Raw ENSDF-derived nucleus files:

    ensdf_24Mg.txt
    ensdf_28Si.txt
    ensdf_48Ca.txt
    ensdf_56Fe.txt
    ensdf_60Ni.txt
    ensdf_90Zr.txt
    ensdf_100Mo.txt
    ensdf_116Sn.txt
    ensdf_120Sn.txt
    ensdf_150Nd.txt
    ensdf_152Sm.txt
    ensdf_166Er.txt
    ensdf_174Yb.txt
    ensdf_208Pb.txt
    ensdf_238U.txt

Each file contains level information for a single nucleus.  
Energy levels are reported in keV.


Conversion Script
-----------------

The script

    ensdf_to_csv_ladders.py

parses all ENSDF files in this directory and extracts the nuclear
excitation energy levels.

The script searches for lines containing:

    " L "

which correspond to level entries in ENSDF formatting.

From those lines it extracts:

    energy_keV


Output
------

Running the script produces a unified dataset:

    nuclear_level_ladders.csv


Output columns:

    nucleus        — nucleus identifier (e.g. 56Fe, 208Pb)
    level_index    — ordered index of the energy level
    energy_keV     — excitation energy (keV)
    spacing_keV    — spacing between consecutive levels (keV)

Spacing is computed as:

    spacing(n) = E(n) − E(n−1)

The first level has spacing = NULL.


Processing Steps
----------------

1. Scan directory for files matching:

       ensdf_*.txt

2. Extract energy levels from ENSDF level records.

3. Remove duplicate energies.

4. Sort energies in ascending order.

5. Compute nearest-level spacing.

6. Export unified ladder dataset.


Usage
-----

Run inside the folder containing the ENSDF files:

    python ensdf_to_csv_ladders.py


Output file:

    nuclear_level_ladders.csv


Role in UNNS Research
---------------------

The resulting ladder dataset is used as input for UNNS structural
analysis chambers studying spectral structure formation in atomic
nuclei.

The nuclear spectra ladders allow comparison of structural stability
patterns across:

    • atomic spectra
    • molecular spectra
    • nuclear energy levels
    • random matrix ensembles

This enables cross-domain testing of the UNNS Substrate structural
law hypothesis.


Notes
-----

All files in this folder are raw inputs.
No preprocessing, normalization, or filtering is applied here.

The generated CSV file is the dataset used by the UNNS chamber
analysis pipeline.
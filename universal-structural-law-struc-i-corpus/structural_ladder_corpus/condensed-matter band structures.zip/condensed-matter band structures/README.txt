README.txt
Condensed Matter Structural Ladder Dataset
UNNS Substrate Program – STRUC-I Chambers

Overview
This dataset contains structural ladder representations derived from
condensed matter materials datasets. Each ladder corresponds to a
physical property measured or computed for a family of materials.

The ladders were generated so that they can be analyzed using the
STRUC-I chamber of the UNNS Substrate Program, which studies the
structural admissibility of ordered sequences under stochastic
perturbations.

The central inequality tested by STRUC-I is:

    inv(Pε ; L) ≤ ν(Vε(L))

where inv counts rank inversions induced by perturbations and ν(V)
represents the vulnerability budget determined by the ladder gap
structure.

Dataset Domain
family: condensed_matter
class: materials_properties

Folder Structure

FeO_multy_property/
    Structural ladders derived from multiple physical properties of
    iron oxide (FeO) compounds.

Germanium family_Ge_ladder/
    Ladders derived from material properties of germanium-based
    compounds.

KSiO_family_ladder/
    Ladders constructed from potassium–silicon–oxygen material systems.

Metallic dataset_Cu_ladder/
    Structural ladders derived from copper-based metallic materials.
    Note: metallic systems often exhibit zero band gaps.

Oxide insulators_O_ladder/
    Ladders derived from oxide insulator materials datasets.

Silicon family_Si_ladder/
    Ladders constructed from silicon-based compounds and materials.

SnO_family_ladder/
    Ladders derived from tin oxide (SnO) material datasets.

TiO_family_ladder/
    Ladders derived from titanium oxide material systems.

TiO2_family_ladder/
    Ladders derived from titanium dioxide compounds.

VO_family_ladder/
    Ladders derived from vanadium oxide materials.

Data Representation

Each ladder is stored as a CSV file containing a single column:

    energy

The values represent ordered structural levels extracted from the
original materials dataset. The levels are sorted in ascending order to
form a structural ladder suitable for STRUC-I analysis.

Conversion Procedure

1. Extract relevant physical property values from the materials dataset
2. Remove missing or invalid entries
3. Sort values into ascending order
4. Export as ladder dataset

Purpose

These ladders enable cross-domain structural analysis of condensed
matter systems within the UNNS admissibility geometry framework.

By testing ladders derived from diverse physical domains, the program
investigates whether structural admissibility is a universal property
of realizable physical systems.

Program

UNNS Substrate Research Program
Chamber: STRUC-I
Version: 1.0.4
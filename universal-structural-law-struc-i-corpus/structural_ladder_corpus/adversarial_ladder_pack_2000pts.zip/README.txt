ADVERSARIAL LADDER PACK FOR STRUC-I
Generated from: molecular_H2O_ladder.csv
Detected source value column: energy_cm1
Point count per ladder: 2000

Files:
1. real_ladder.csv
   Sorted ladder derived from the uploaded H2O source.

2. shuffled_ladder.csv
   Same values as the real ladder, but randomly shuffled.
   Purpose: destroys ordering while preserving the exact value multiset.

3. smooth_rank_surrogate.csv
   Monotone smooth surrogate across the same numeric range.
   Purpose: preserves coarse range/trend while removing local gap hierarchy.

4. histogram_matched_synthetic.csv
   Histogram/value-distribution-matched synthetic sequence with reordered local structure.
   Purpose: keeps the same marginal value distribution while changing structural organization.

Suggested STRUC-I loading:
Slot 1: real_ladder.csv
Slot 2: shuffled_ladder.csv
Slot 3: smooth_rank_surrogate.csv
Slot 4: histogram_matched_synthetic.csv

All four files contain exactly 2000 points in a single column named 'value'.

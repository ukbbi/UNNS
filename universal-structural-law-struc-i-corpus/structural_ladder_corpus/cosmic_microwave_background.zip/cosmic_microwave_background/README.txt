README.txt
Cosmic Microwave Background Spectral Ladders
UNNS Substrate Program – STRUC-I Dataset

Overview
This dataset contains ladder representations of the cosmic microwave
background (CMB) angular power spectra measured by the Planck satellite.

The original Planck power spectrum tables were converted into ordered
ladder sequences so they can be analyzed by the STRUC-I chamber of the
UNNS Substrate Program.

The ladders allow testing of the Universal Ladder Admissibility
inequality under stochastic perturbations.

    inv(Pε ; L) ≤ ν(Vε(L))

Dataset Domain
family: cosmic_microwave_background
class: cosmological_power_spectra

Files

cmb_EE_cosmic_microwave_background_ladder.csv
Derived from the Planck E-mode polarization power spectrum.

cmb_TE_cosmic_microwave_background_ladder.csv
Derived from the temperature–polarization cross-correlation spectrum.

cmb_TT_cosmic_microwave_background_ladder.csv
Derived from the temperature anisotropy power spectrum.

Typical ladder size: ~2000 ordered levels.

File Format

Each CSV file contains a single column:

energy

Values represent sorted spectral amplitudes extracted from the Planck
angular power spectrum measurements.

These values are interpreted by the STRUC-I chamber as ladder levels.

Conversion Method

1. Extract spectral amplitude column from Planck power spectrum tables
2. Remove missing values
3. Sort values into ascending order
4. Export as single-column ladder dataset

Source Data

Planck Collaboration
CMB Power Spectra (TT, TE, EE)

Original files are stored in the "source_planck_data" directory for
traceability.

Purpose

These ladders enable structural analysis of cosmological spectral data
using the UNNS admissibility geometry framework.

Program

UNNS Substrate Research Program
Chamber: STRUC-I
Version: 1.0.4
Moon gravity STRUCT-I ladder pack
Source: AIUB-GRL350A.gfc / grav_i_moon_L300_subset.json
Preprocessing: excluded l < 2; single-column CSV ladders with header value.
Derived amplitude A = sqrt(C^2 + S^2).
Degree power = sum(A^2) by degree. Degree RMS = sqrt(mean(A^2)) by degree.

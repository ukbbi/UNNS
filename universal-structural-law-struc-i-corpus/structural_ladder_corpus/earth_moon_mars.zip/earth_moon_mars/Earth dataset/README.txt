Converted from grav_i_eigen6c4_L720_subset.json (EIGEN-6C4 subset, l<=720).
Source columns: l, m, C, S, sigC, sigS.
All ladders exclude l<2 (monopole/dipole) to avoid trivial terms.

Files:
- grav_i_eigen6c4_L720_absC_ladder.csv : descending |C_lm| values
- grav_i_eigen6c4_L720_absS_ladder.csv : descending |S_lm| values
- grav_i_eigen6c4_L720_amp_ladder.csv : descending sqrt(C_lm^2 + S_lm^2) values
- grav_i_eigen6c4_L720_sigma_amp_ladder.csv : descending sqrt(sigC^2 + sigS^2) values
- grav_i_eigen6c4_L720_degree_power_ladder.csv : descending per-degree sum_m(C_lm^2 + S_lm^2)
- grav_i_eigen6c4_L720_degree_rms_ladder.csv : descending per-degree RMS amplitude sqrt(sum_m(C^2+S^2)/(2l+1))

grav_i_eigen6c4_L720_absC_ladder.csv: n=260278, max=0.000484165217061, min=1.3746379068e-16
grav_i_eigen6c4_L720_absS_ladder.csv: n=259559, max=1.41437833274e-06, min=3.0006814133e-18
grav_i_eigen6c4_L720_amp_ladder.csv: n=260278, max=0.000484165217061, min=8.211622312627068e-15
grav_i_eigen6c4_L720_sigma_amp_ladder.csv: n=260278, max=3.395809632473529e-11, min=1.2607e-14
grav_i_eigen6c4_L720_degree_power_ladder.csv: n=260277, max=2.344159574117252e-07, min=6.743074100523471e-29
grav_i_eigen6c4_L720_degree_rms_ladder.csv: n=260277, max=0.0002165252675378674, min=2.459186875809885e-16

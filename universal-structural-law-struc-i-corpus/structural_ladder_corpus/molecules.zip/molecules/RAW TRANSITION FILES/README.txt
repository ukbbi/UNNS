MOLECULAR ENERGY LEVEL DATA — RAW TRANSITION FILES
==================================================

Folder name:
molecules


Purpose
-------

This folder contains raw molecular spectral transition data used to
reconstruct molecular energy-level ladders for UNNS structural analysis.

Unlike atomic or nuclear spectra, molecular datasets usually provide
transition information rather than direct level tables. The conversion
script reconstructs the energy levels from these transitions.


Contents
--------

Raw transition dataset:

    69b46636.out

This file contains molecular spectral transitions for the ozone molecule
(O₃). The dataset includes transition frequencies and lower-state
energies.


Conversion Script
-----------------

The script in this folder reads the transition dataset and reconstructs
the molecular energy ladder.

It uses two values from the dataset:

    nu       — transition frequency
    elower   — lower-state energy

For each transition the script computes:

    e_upper = e_lower + nu

Both the lower and upper levels are added to the level set.


Output
------

Running the script produces the ladder dataset:

    molecular_O3_ladder.csv


Output columns:

    molecule      — molecule identifier (O3)
    level_index   — ordered index of the energy level
    energy_cm1    — level energy in cm⁻¹
    spacing_cm1   — spacing between consecutive levels


Spacing definition:

    spacing(n) = E(n) − E(n−1)

The first level has an empty spacing value.


Processing Steps
----------------

1. Read the transition file:

       69b46636.out

2. Extract fields:

       nu
       elower

3. Compute upper-state energies:

       e_upper = e_lower + nu

4. Collect all lower and upper levels.

5. Remove duplicates.

6. Sort energy levels.

7. Compute nearest-neighbor spacing.

8. Export the ladder dataset.


Usage
-----

Run inside the folder:

    python <script_name>.py

Output file generated:

    molecular_O3_ladder.csv


Role in UNNS Research
---------------------

The reconstructed molecular ladder is used as input for UNNS structural
analysis chambers investigating spectral structure formation across
different physical domains.

Molecular spectra provide an intermediate complexity regime between
atomic spectra and nuclear spectra, making them valuable for testing
cross-domain structural behavior.

Domains currently studied include:

    • atomic spectral ladders
    • molecular vibrational–rotational ladders
    • nuclear energy-level ladders
    • random matrix spectra


Notes
-----

The raw transition dataset is preserved unchanged in this folder.

The ladder CSV file produced by the script is the dataset used for
subsequent UNNS chamber analysis.
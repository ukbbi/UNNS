import csv

input_file = "69b46636.out"
output_file = "molecular_O3_ladder.csv"
molecule_name = "O3"

levels = set()

with open(input_file, "r", encoding="utf-8") as f:
    reader = csv.DictReader(f)
    for row in reader:
        try:
            nu = float(row["nu"])
            e_lower = float(row["elower"])
        except (KeyError, ValueError):
            continue

        e_upper = e_lower + nu
        levels.add(round(e_lower, 10))
        levels.add(round(e_upper, 10))

sorted_levels = sorted(levels)

with open(output_file, "w", newline="", encoding="utf-8") as f:
    writer = csv.writer(f)
    writer.writerow(["molecule", "level_index", "energy_cm1", "spacing_cm1"])

    prev = None
    for i, energy in enumerate(sorted_levels):
        spacing = "" if prev is None else round(energy - prev, 10)
        writer.writerow([molecule_name, i, energy, spacing])
        prev = energy

print(f"Created {output_file} with {len(sorted_levels)} energy levels.")
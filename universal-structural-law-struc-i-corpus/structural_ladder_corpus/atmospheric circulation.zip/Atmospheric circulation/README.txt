ERA5 250 hPa U-wind STRUCT-I ladder pack

Source file:
- data_stream-oper_stepType-instant.nc

Source metadata:
- valid_time: 2023-01-01T12:00:00.000000000
- pressure_level: 250 hPa
- variable: u (zonal wind, m/s)
- grid: 721 latitudes x 1440 longitudes

STRUCT-I-ready ladders (single-column CSV with header 'value'):
1. era5_250hpa_latband_absmean_u_ladder.csv
   - 12 latitude bands from 60S to 60N in 10-degree steps
   - area-weighted mean absolute zonal wind in each band
2. era5_250hpa_latband_signedmean_u_ladder.csv
   - same bands, signed area-weighted mean zonal wind
3. era5_250hpa_latband_absmax_u_ladder.csv
   - same bands, maximum absolute zonal wind in each band
4. era5_250hpa_top12_jet_regions_absmean_u_ladder.csv
   - strongest 12 thirty-degree longitude sectors within the NH/SH jet belts (20-60N, 20-60S)
5. era5_250hpa_global_lonsector_absmean_u_ladder.csv
   - 12 global 30-degree longitude sectors, area-weighted mean absolute zonal wind

Companion label files (not for direct chamber upload) map nodes to bands/regions.

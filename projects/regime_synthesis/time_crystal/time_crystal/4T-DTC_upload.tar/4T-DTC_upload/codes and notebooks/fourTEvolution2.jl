using ITensors
using LinearAlgebra

function two_body_hamiltonian_1st_half(J::Number,
                                       h::Number,
                                       N::Int64,
                                       s::Array,
                                       ω::Number,
                                       tval::Number)
        ham_nn = ITensor[]
        ham_nnn = ITensor[]
        coswt = 1+cos(ω * tval)
        # nearest-neighbor terms
        # XX, YY
        for j = 1:2:N
            s1 = s[j]
            s2 = s[j+1] 
            h2j = (-h/2)*2*op("Sx",s1)*2*op("Sx",s2) + (h/2)*coswt*2*op("Sy",s1)*2*op("Sy",s2)
            # h2j = (-h/2)*2*op("Sx",s1)*2*op("Sz",s2)
            push!(ham_nn,h2j)
        end

        # next nearest-neighbor terms 
        # ZZ
        for j = 1:2:(N-2)
            s1 = s[j]
            s2 = s[j+2]
            h2j = (-J)*2*op("Sz",s1)*2*op("Sz",s2)
            push!(ham_nnn,h2j)

        end
        return ham_nn, ham_nnn

end

function two_body_hamiltonian_1st_half_concatenate(J::Number,
                                                   h::Number,
                                                   N::Int64,
                                                   s::Array,
                                                   ω::Number,
                                                   tval::Number)
        ham_array = ITensor[]
        coswt = (1+cos(ω * tval))
        for j = 1:2:(N-2)
            s1 = s[j]
            s2 = s[j+1]
            s3 = s[j+2]
            h2jnn = (-h/2)*2*op("Sx",s1)*2*op("Sx",s2) + (h/2)*coswt*2*op("Sy",s1)*2*op("Sy",s2)
            push!(ham_array,h2jnn)
            h2jnnn = (-J)*2*op("Sz",s1)*2*op("Sz",s3)
            push!(ham_array,h2jnnn)
        end
        s1 = s[7]
        s2 = s[8]
        h2 = (-h/2)*2*op("Sx",s1)*2*op("Sx",s2) + (h/2)*coswt*2*op("Sy",s1)*2*op("Sy",s2)
        push!(ham_array,h2)

        return ham_array

end

function two_body_hamiltonian_2nd_half(M::Number,
                                       N::Int64,
                                       s::Array)
        ham_odd = ITensor[]
        ham_even = ITensor[]
        # X field terms 
        # odd bonds 
        for j=1:2:N
            s1 = s[j]
            s2 = s[j+1]
            if j == 7
                h2j = M * op("Id",s1) * 2* op("Sx",s2)
                push!(ham_odd,h2j)
            else
                h2j = 0.5 * op("Id",s1) * M * 2 * op("Sx",s2)
                push!(ham_odd,h2j)
            end
        end

        # even bonds
        for j=2:2:(N-2)
            s1 = s[j]
            s2 = s[j+1]
            h2j = 0.5 * M * 2 * op("Sx",s1) * op("Id",s2)
            push!(ham_even,h2j)
        end

        return ham_odd, ham_even

end

function prepare_1st_half_U_bond(dt::Number,
                                 ham_nn::Array,
                                 ham_nnn::Array)
    # nn bond unitary operator
    U_nn = ITensor[]
    U_nnn = ITensor[]
    for j=1:length(ham_nn)
        U2_body_nn = exp(-1.0im * dt * ham_nn[j])
        push!(U_nn,U2_body_nn)
    end
    
    # nnn bond unitary operator 
    for j=1:length(ham_nnn)
        U2_body_nnn = exp(-1.0im * dt * ham_nnn[j])
        push!(U_nnn,U2_body_nnn)
    end

    return U_nn, U_nnn

end 

function prepare_1st_half_U_bond_concatenate(dt::Number,ham_array::Array)
    U = ITensor[]
    for j = 1:length(ham_array)
        U2_body = exp(-1.0im * dt * ham_array[j])
        push!(U,U2_body)
    end
    return U
end

function prepare_2nd_half_U_bond(dt::Number,
                                 ham_odd::Array,
                                 ham_even::Array)
    U_odd = ITensor[]
    U_even = ITensor[]
    # odd bond unitary operator
    for j=1:length(ham_odd)
        U2body = exp(-1.0im * dt * ham_odd[j])
        push!(U_odd,U2body)
    end

    # even bond unitary operator
    for j=1:length(ham_even) 
        U2body = exp(-1.0im * dt * ham_even[j])
        push!(U_even,U2body)
    end

    return U_odd,U_even

end

function evoST_1st_order_one_step(ψ::MPS,UOdd::Array,UEven::Array,cutoff,maxdim::Int64)
    # e^{-i H_{odd} dt}|ψ>
    ψ = apply(UOdd,ψ;cutoff=cutoff,maxdim=maxdim)
    # e^{-i H_{even} dt}|ψ>
    ψ = apply(UEven,ψ;cotoff=cutoff,maxdim=maxdim)  
    return ψ  
end

function evoST_1st_order_one_step_first_half(ψ::MPS,U::Array,cutoff,maxdim::Int64)
    ψ = apply(U,ψ;cutoff=cutoff,maxdim=maxdim)
    return ψ

end

function single_period_Trotter_1st_order(J::Number,
                                         h::Number,
                                         N::Int64,
                                         s::Array,   
                                         ω::Number,
                                         M::Number,
                                         T::Number,
                                         dt::Number,
                                         ψ::MPS,
                                         cutoff,
                                         period_index::Int64,
                                         maxdim::Int64)
    # first-half evolution 
    total_step = T/2/dt
    for i=1:total_step
        tval = (i-1) * dt + T * (period_index-1)
        ham_nn,ham_nnn = two_body_hamiltonian_1st_half(J,h,N,s,ω,tval)
        U_nn, U_nnn = prepare_1st_half_U_bond(dt,ham_nn,ham_nnn)
        ψ = evoST_1st_order_one_step(ψ,U_nn,U_nnn,cutoff,maxdim)
        normvalinv = 1.0/norm(ψ);
        ψ = ψ * normvalinv;
        # print(sum(2*expect(ψ,"Sz";sites=1:2:N))/(N/2))
    end

    #second-half evolution 
    total_step = T/2/dt 
    for i=1:total_step 
        ham_odd,ham_even = two_body_hamiltonian_2nd_half(M,N,s)
        U_odd,U_even = prepare_2nd_half_U_bond(dt,ham_odd,ham_even)
        ψ = evoST_1st_order_one_step(ψ,U_odd,U_even,cutoff,maxdim)
        normvalinv = 1.0/norm(ψ);
        ψ = ψ * normvalinv;
        # print(sum(2*expect(ψ,"Sz";sites=1:2:N))/(N/2))
    end
    return ψ
 
end

function single_period_Trotter_1st_order_concatenate(J,h,N,s,ω,M,
                                                        T,
                                                        dt,
                                                        ψ,
                                                        cutoff,
                                                        period_index,
                                                        maxdim::Int64)
        # first-half evolution 
        total_step = T/2/dt
        for i=1:total_step
        tval = (i-1) * dt + T * (period_index-1)
        ham_array= two_body_hamiltonian_1st_half_concatenate(J,h,N,s,ω,tval)
        U = prepare_1st_half_U_bond_concatenate(dt,ham_array)
        ψ = evoST_1st_order_one_step_first_half(ψ,U,cutoff,maxdim)
        normvalinv = 1.0/norm(ψ);
        ψ = ψ * normvalinv;
        # print(sum(2*expect(ψ,"Sz";sites=1:2:N))/(N/2))
        end

        #second-half evolution 
        total_step = T/2/dt 
        for i=1:total_step 
        ham_odd,ham_even = two_body_hamiltonian_2nd_half(M,N,s)
        U_odd,U_even = prepare_2nd_half_U_bond(dt,ham_odd,ham_even)
        ψ = evoST_1st_order_one_step(ψ,U_odd,U_even,cutoff,maxdim)
        normvalinv = 1.0/norm(ψ);
        ψ = ψ * normvalinv;
        # print(sum(2*expect(ψ,"Sz";sites=1:2:N))/(N/2))
        end
        return ψ

end

function single_period_Trotter!(J,h,N,s,ω,M,T,dt,ψ,cutoff,period_index,maxdim::Int64)
    # first-half evolution 
    total_step = T/2/dt
    for i=1:total_step
        tval = (i-1) * dt + T * (period_index-1)
        ham_nn,ham_nnn = two_body_hamiltonian_1st_half(J,h,N,s,ω,tval)
        U_nn, U_nnn = prepare_1st_half_U_bond(dt,ham_nn,ham_nnn)
        ψ = evoST_1st_order_one_step(ψ,U_nn,U_nnn,cutoff,maxdim)
        normvalinv = 1.0/norm(ψ);
        ψ = ψ * normvalinv;
        # print(sum(2*expect(ψ,"Sz";sites=1:2:N))/(N/2))
    end

    #second-half evolution 
    total_step = T/2/dt 
    for i=1:total_step
        ham_odd,ham_even = two_body_hamiltonian_2nd_half(M,N,s)
        U_odd,U_even = prepare_2nd_half_U_bond(dt,ham_odd,ham_even)
        ψ = evoST_1st_order_one_step(ψ,U_odd,U_even,cutoff,maxdim)
        normvalinv = 1.0/norm(ψ);
        ψ = ψ * normvalinv;
        # print(sum(2*expect(ψ,"Sz";sites=1:2:N))/(N/2))
    end
    return ψ

end

function DTC_time_evolution(J,h,N,s,ω,M,T,dt,ψ,cutoff,Nperiods,Szlist,tlist,maxdim::Int64)
    for k = 1:Nperiods
        ψ = single_period_Trotter_1st_order(J,h,N,s,ω,M,
                                             T,
                                             dt,
                                             ψ,
                                             cutoff,
                                             k,
                                             maxdim)
        temp1 = sum(2*expect(ψ,"Sz";sites=1:2:N))/(N/2);
        append!(Szlist,temp1)
        append!(tlist,k*measure_step*dt)
    end

    return tlist,Szlist
end

function DTC_time_evolution_site_measurement(J,h,N,s,ω,M,T,dt,ψ,cutoff,Nperiods,Szlist,tlist,maxdim::Int64)
    for k = 1:Nperiods
        ψ = single_period_Trotter_1st_order(J,h,N,s,ω,M,
                                             T,
                                             dt,
                                             ψ,
                                             cutoff,
                                             k,
                                             maxdim)
        # temp1 = sum(2*expect(ψ,"Sz";sites=1:2:N))/(N/2);
        # expect(ψ,"Sz";sites=1:2:N)
        append!(Szlist,temp1)
        append!(tlist,k*measure_step*dt)
    end

    return tlist,Szlist
end

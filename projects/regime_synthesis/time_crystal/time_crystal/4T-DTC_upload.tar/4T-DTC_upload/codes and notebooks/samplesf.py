# -*- coding: utf-8 -*-
"""
Created on Wed Apr 14 10:32:40 2021

@author: physrwb
"""

from quspin.operators import hamiltonian, exp_op # Hamiltonians and operators
from quspin.basis import spin_basis_1d, spinless_fermion_basis_1d, spin_basis_general # Hilbert space spin basis
import numpy as np # generic math functions
import matplotlib.pyplot as plt # plotting library
import random as ran
import matplotlib as mplt
import scipy.linalg as la


no_checks = dict(check_herm=False,check_symm=False,check_pcon=False)

font = {'family' : 'normal',
        'weight' : 'bold',
        'size'   : 22}

plt.rc('font', **font)

######## edge spectral function calculation


##### define model parameters #####
N_2d = 9 # size of surface code
Nd = 1 # number of disorder realizations

###### setting up bases ######
basis_spin = spin_basis_general(N_2d) # 2d - basis
print("Size of 2D H-space: {Ns:d}".format(Ns=basis_spin.Ns))

Jz1=0.3 # ZZZZ stabilizer strength for the first repetition 0.75
Jx1=0.3 # XXXX stabilizer strength
W=1 # disorder strength 0.5
hz=(1-0.05)*np.pi/2 # logical Z strength 0.08
Whz=0.02*np.pi/2
hx=(1-0.05)*np.pi/2 # logical X strength 0.08
Whx=0.02*np.pi/2
s0=0j # 0 spectral
s02=0j
spi=0j # pi spectral
spi2=0j

######### construct correlated magnetization operator
if N_2d == 4:
    h_fieldm1=[[1,0,1]] # remember to change this when the system size is varied
    static_spinm1 =[["zz",h_fieldm1]] # static part of M 
    h_fieldm2=[[1,0,2]] # remember to change this when the system size is varied
    static_spinm2 =[["xx",h_fieldm2]] # static part of M
elif N_2d == 9:
    h_fieldm1=[[1,0,1,2]] # remember to change this when the system size is varied
    static_spinm1 =[["zzz",h_fieldm1]] # static part of M
    h_fieldm2=[[1,0,3,6]] # remember to change this when the system size is varied
    static_spinm2 =[["xxx",h_fieldm2]] # static part of M

M1=hamiltonian(static_spinm1,[],basis=basis_spin**no_checks) 
M2=hamiltonian(static_spinm2,[],basis=basis_spin,**no_checks) 


for dis in range(Nd):
    ######### Setting up Hamiltonian
    if N_2d == 4:
        SX1=[[1,0,1]]
        SX2=[[1,2,3]]
        sx1=hamiltonian([["xx",SX1]],[],basis=basis_spin,**no_checks)
        sx2=hamiltonian([["xx",SX2]],[],basis=basis_spin,**no_checks)
        JZZZZ = [[-ran.uniform(Jz1-W/2,Jz1+W/2),0,1,2,3]]
        JXXXXbound = [[-ran.uniform(Jx1-W/2,Jx1+W/2),0,1],[-ran.uniform(Jx1,Jx1+W),2,3]]
        h = [[ran.uniform(hx-Whx/2,hx+Whx/2),0],[ran.uniform(hx-Whx/2,hx+Whx/2),2]]
        hh = [[ran.uniform(hz-Whz/2,hz+Whz/2),0],[ran.uniform(hz-Whz/2,hz+Whz/2),1]]
        Hx = hamiltonian([["zzzz",JZZZZ],["xx",JXXXXbound]],[],basis=basis_spin,dtype=np.float64,**no_checks)
        Hh = hamiltonian([["x",h]],[],basis=basis_spin,**no_checks)
        Hhh = hamiltonian([["z",hh]],[],basis=basis_spin,**no_checks)
    elif N_2d == 9:
        SX1=[[1,0,1,2,3]]
        SX2=[[1,4,5,7,8]]
        SZ1=[[1,1,2,4,5]]
        SZ2=[[1,3,4,6,7]]
        SXb1=[[1,1,2]]
        SXb2=[[1,6,7]]
        SZb1=[[1,0,3]]
        SZb2=[[1,5,8]]
        sx1=hamiltonian([["xxxx",SX1]],[],basis=basis_spin,**no_checks)
        sx2=hamiltonian([["xxxx",SX2]],[],basis=basis_spin,**no_checks)
        sz1=hamiltonian([["zzzz",SZ1]],[],basis=basis_spin,**no_checks)
        sz2=hamiltonian([["zzzz",SZ2]],[],basis=basis_spin,**no_checks)
        sxb1=hamiltonian([["xx",SXb1]],[],basis=basis_spin,**no_checks)
        sxb2=hamiltonian([["xx",SXb2]],[],basis=basis_spin,**no_checks)
        szb1=hamiltonian([["zz",SZb1]],[],basis=basis_spin,**no_checks)
        szb2=hamiltonian([["zz",SZb2]],[],basis=basis_spin,**no_checks)
        JXXXX = [[-ran.uniform(Jx1-W/2,Jx1+W/2),0,1,3,4], [-ran.uniform(Jx1-W/2,Jx1+W/2),4,5,7,8]]
        JXXXXbound = [[-ran.uniform(Jx1-W/2,Jx1+W/2),1,2], [-ran.uniform(Jx1-W/2,Jx1+W/2),6,7]]
        JZZZZ = [[-ran.uniform(Jz1-W/2,Jz1+W/2),1,2,4,5], [-ran.uniform(Jz1-W/2,Jz1+W/2),3,4,6,7]]
        JZZZZbound = [[-ran.uniform(Jz1-W/2,Jz1+W/2),0,3], [-ran.uniform(Jz1-W/2,Jz1+W/2),5,8]]
        h = [[ran.uniform(hx-Whx/2,hx+Whx/2),0],[ran.uniform(hx-Whx/2,hx+Whx/2),3],[ran.uniform(hx-Whx/2,hx+Whx/2),6],[ran.uniform(hx-Whx/2,hx+Whx/2)-np.pi/2,1],[ran.uniform(hx-Whx/2,hx+Whx/2)-np.pi/2,4],[ran.uniform(hx-Whx/2,hx+Whx/2)-np.pi/2,7],[ran.uniform(hx-Whx/2,hx+Whx/2)-np.pi/2,2],[ran.uniform(hx-Whx/2,hx+Whx/2)-np.pi/2,5],[ran.uniform(hx-Whx/2,hx+Whx/2)-np.pi/2,8]]
        hh = [[ran.uniform(hz-Whz/2,hz+Whz/2),0],[ran.uniform(hz-Whz/2,hz+Whz/2),1],[ran.uniform(hz-Whz/2,hz+Whz/2),2],[ran.uniform(hz-Whz/2,hz+Whz/2)-np.pi/2,3],[ran.uniform(hz-Whz/2,hz+Whz/2)-np.pi/2,4],[ran.uniform(hz-Whz/2,hz+Whz/2)-np.pi/2,5],[ran.uniform(hz-Whz/2,hz+Whz/2)-np.pi/2,6],[ran.uniform(hz-Whz/2,hz+Whz/2)-np.pi/2,7],[ran.uniform(hz-Whz/2,hz+Whz/2)-np.pi/2,8]]
        Hx = hamiltonian([["zzzz",JZZZZ],["xxxx",JXXXX],["xx",JXXXXbound],["zz",JZZZZbound]],[],basis=basis_spin,dtype=np.float64,**no_checks)
        Hh = hamiltonian([["x",h]],[],basis=basis_spin,**no_checks)
        Hhh = hamiltonian([["z",hh]],[],basis=basis_spin,**no_checks)

    U1=la.expm(-1j*Hx.toarray())
    U2=la.expm(-1j*Hh.toarray())
    U3=la.expm(-1j*Hhh.toarray())

    U=np.dot(np.dot(U3,U2),U1)
    
    eigvals, eigvecs = la.eig(U)
    eigvals=np.angle(eigvals)
    N=0j # normalization constant
    N2=0j
    
    sample=ran.sample(range(0,np.size(eigvals)),32)
    
    
    ######## Construct the normalization constants
    for l in range(np.size(eigvals)):
        for ll in range(np.size(sample)): 
            N=N+np.abs(np.dot(np.conj(np.transpose(eigvecs[:,int(sample[ll])])),np.dot(M1.toarray(),eigvecs[:,l])))**2
            N2=N2+np.abs(np.dot(np.conj(np.transpose(eigvecs[:,int(sample[ll])])),np.dot(M2.toarray(),eigvecs[:,l])))**2
    
    ####### Construct the spectral functions with respect to operators M1 and M2 respectively
    for l in range(np.size(eigvals)):
        for ll in range(np.size(sample)):
            if np.abs(eigvals[int(sample[ll])]-eigvals[l])<0.01:
                s0=s0+np.abs(np.dot(np.conj(np.transpose(eigvecs[:,int(sample[ll])])),np.dot(M1.toarray(),eigvecs[:,l])))**2/N
                s02=s02+np.abs(np.dot(np.conj(np.transpose(eigvecs[:,int(sample[ll])])),np.dot(M2.toarray(),eigvecs[:,l])))**2/N2
            if np.abs(np.abs(eigvals[int(sample[ll])]-eigvals[l])-np.pi)<0.01:
                spi=spi+np.abs(np.dot(np.conj(np.transpose(eigvecs[:,int(sample[ll])])),np.dot(M1.toarray(),eigvecs[:,l])))**2/N
                spi2=spi2+np.abs(np.dot(np.conj(np.transpose(eigvecs[:,int(sample[ll])])),np.dot(M2.toarray(),eigvecs[:,l])))**2/N2
    
    print(dis)

s0=s0/Nd
s02=s02/Nd
spi=spi/Nd
spi2=spi2/Nd
    
    
    
    
    
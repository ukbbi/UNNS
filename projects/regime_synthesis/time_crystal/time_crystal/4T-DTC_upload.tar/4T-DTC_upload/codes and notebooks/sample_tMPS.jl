using ITensors
using LinearAlgebra
# using Plots,PlotThemes
# theme(:dao)
using SparseArrays
using HDF5
# using LaTeXStrings
include("SpinHalfBaseSparse.jl")
include("fourTEvolution.jl")

let
    # Parameters
    N = parse(Int64,ARGS[1]);
    T = 1
    h = parse(Float64,ARGS[4])*pi/T
    M = parse(Float64,ARGS[6])*pi/T
    J = parse(Float64,ARGS[5])*pi/T 
    ω = 2*pi/T
    t_tot = parse(Int64,ARGS[2])*T
    dt = 0.01
    measure_step = 100
    Nsteps = Int(t_tot/dt);
    Nperiods = Int(Nsteps/measure_step)
    maxdim = parse(Int64,ARGS[3];)
    path = string(ARGS[7]);
    cut_off = 1E-8;

    # MPS time evolution
    ## Initial MPS preparation
    # Make an array of 'site' indices
    s = siteinds("S=1/2",N;conserve_qns=false)
    ψ = MPS(ComplexF64,s);
    for i=1:N
    #     ψ[i][1,1,1]=1/sqrt(2);
    #     ψ[i][1,2,1]=1/sqrt(2)*1im;
        ψ[i][1,1,1]=1;
        ψ[i][1,2,1]=0;
    end
    orthogonalize!(ψ,1);

    # Initial measurement
    Szlist = Array{Float64,1}(undef,0);
    tlist = Array{Float64,1}(undef,0);
    temp = sum(2*expect(ψ,"Sz";sites=1:2:N))/(N/2);
    append!(tlist,0)
    append!(Szlist,temp)
    # print("==1==\n")

    for k = 1:Nperiods
        ψ = single_period_Trotter_1st_order(J,h,N,s,ω,M,
                                             T,
                                             dt,
                                             ψ,
                                             cut_off,
                                             k,
                                             maxdim)
        temp1 = sum(2*expect(ψ,"Sz";sites=1:2:N))/(N/2);
        append!(Szlist,temp1)
        append!(tlist,k*measure_step*dt)
        print(string(k) * "\n")

        GC.gc()
        # # Save data
        # print(k)
        # filename = "N"*ARGS[1]*"ttotal"*ARGS[2]*"maxdim"*ARGS[3]*".h5"
        # h5open(path * "/" * filename,"w") do file
        #     g = create_group(file, "Parameters") # create a group
        #     g["N"] = N
        #     g["T"] = T
        #     g["h"] = h
        #     g["M"] = M
        #     g["dt"] = dt
        #     g["ttotal"] = t_tot
        #     # g["initialstate"] = initial_state_type
        #     g["cutoff"] = cut_off
        #     g["maxbd"] = maxdim
        #     g["measurestep"] = measure_step

        #     R = create_group(file,"Results")
        #     memi = Int64(Sys.free_memory())
        #     write(file, "Results/Mz", Szlist)
        #     write(file, "Results/tlist", tlist)
        #     meme = Int64(Sys.free_memory())
        #     println("Memory usage n=$k $((memi-meme)/1e9) GB")
        #     # attributes(g)["Description"] = "This group contains only a single dataset" # an attribute
        # end
        
        

    end

    # print("==2==\n")
    # for k = 1:Nperiods
    #     print(k)
    #     state = single_period_Trotter!(J,h,N,s,ω,M,
    #                                          T,
    #                                          dt,
    #                                          ψ,
    #                                          1E-8,
    #                                          k)
    #     temp1 = sum(2*expect(ψ,"Sz";sites=1:2:N))/(N/2);
    #     append!(Sylist_mps,temp1)
    #     append!(tlist_mps,k*measure_step*dt)
    # end
   
    # Save data
    filename = "N"*ARGS[1]*"ttotal"*ARGS[2]*"maxdim"*ARGS[3]*"h"*ARGS[4]*"J"*ARGS[5]*"M"*ARGS[6]*".h5"
    # filename = "N"*ARGS[1]*"ttotal"*ARGS[2]*"maxdim"*ARGS[3]*".h5"
    h5open(path * "/" * filename,"w") do file
        g = create_group(file, "Parameters") # create a group
        g["N"] = N
        g["T"] = T
        g["h"] = h
        g["M"] = M
        g["dt"] = dt
        g["ttotal"] = t_tot
        # g["initialstate"] = initial_state_type
        g["cutoff"] = cut_off
        g["maxbd"] = maxdim
        g["measurestep"] = measure_step

        R = create_group(file,"Results")
        write(file, "Results/Mz", Szlist)
        write(file, "Results/tlist", tlist)
        # attributes(g)["Description"] = "This group contains only a single dataset" # an attribute
    end

end
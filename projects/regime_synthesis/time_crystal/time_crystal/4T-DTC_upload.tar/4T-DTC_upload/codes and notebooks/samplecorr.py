# -*- coding: utf-8 -*-
"""
Created on Wed Apr 14 10:32:40 2021

@author: physrwb
"""

from quspin.operators import hamiltonian, exp_op # Hamiltonians and operators
from quspin.basis import spin_basis_1d, spinless_fermion_basis_1d, spin_basis_general # Hilbert space spin basis
import numpy as np # generic math functions
import matplotlib.pyplot as plt # plotting library
import random as ran
import matplotlib as mplt
import scipy.linalg as la


no_checks = dict(check_herm=False,check_symm=False,check_pcon=False)

font = {'family' : 'normal',
        'weight' : 'bold',
        'size'   : 22}

plt.rc('font', **font)

######## generalized two-point correlation


##### define model parameters #####
N_2d = 9 # size of surface code
Nd = 1 # number of disorder realizations

###### setting up bases ######
basis_spin = spin_basis_general(N_2d) # 2d - basis
print("Size of 2D H-space: {Ns:d}".format(Ns=basis_spin.Ns))

Jz1=0.5 # ZZZZ stabilizer strength for the first repetition 0.75
Jx1=0.5 # XXXX stabilizer strength
W=1 # disorder strength 0.5
hz=(1-0.05)*np.pi/2 # logical Z strength 0.08
Whz=0.025*np.pi/2
hx=(1-0.05)*np.pi/2 # logical X strength 0.08
Whx=0.025*np.pi/2
s0=0j # 0 spectral
s02=0j
spi=0j # pi spectral
spi2=0j

######### construct correlated magnetization operator
if N_2d == 4:
    h_fieldm1=[[1,0,1]] # remember to change this when the system size is varied
    static_spinm1 =[["zz",h_fieldm1]] # static part of M 
    h_fieldm2=[[1,0,2]] # remember to change this when the system size is varied
    static_spinm2 =[["xx",h_fieldm2]] # static part of M
    corz0=np.zeros((N_2d,2**4,2**4),dtype=np.complex)
    corx0=np.zeros((N_2d,2**4,2**4),dtype=np.complex)
    cory0=np.zeros((N_2d,2**4,2**4),dtype=np.complex)
    corz=np.zeros((int(np.sqrt(N_2d)),2**4,2**4),dtype=np.complex)
    corx=np.zeros((int(np.sqrt(N_2d)),2**4,2**4),dtype=np.complex)
    cory=np.zeros((int(np.sqrt(N_2d)),2**4,2**4),dtype=np.complex)
    ccorz=np.zeros((int(np.sqrt(N_2d)),2**4,2**4),dtype=np.complex)
    ccorx=np.zeros((int(np.sqrt(N_2d)),2**4,2**4),dtype=np.complex)
    ccory=np.zeros((int(np.sqrt(N_2d)),2**4,2**4),dtype=np.complex)
    for l in range(int(np.sqrt(N_2d))):
        hfield=[[1,l*int(np.sqrt(N_2d)),l*int(np.sqrt(N_2d))+1]]
        hfield2=[[1,l,l+int(np.sqrt(N_2d))]]
        statfieldz=[["zz",hfield]]
        statfieldx=[["xx",hfield]]
        statfieldy=[["yy",hfield]]
        sstatfieldz=[["zz",hfield2]]
        sstatfieldx=[["xx",hfield2]]
        sstatfieldy=[["yy",hfield2]]
        AZ=hamiltonian(statfieldz,[],basis=basis_spin,**no_checks)
        AX=hamiltonian(statfieldx,[],basis=basis_spin,**no_checks)
        AY=hamiltonian(statfieldy,[],basis=basis_spin,**no_checks)
        AAZ=hamiltonian(sstatfieldz,[],basis=basis_spin,**no_checks)
        AAX=hamiltonian(sstatfieldx,[],basis=basis_spin,**no_checks)
        AAY=hamiltonian(sstatfieldy,[],basis=basis_spin,**no_checks)
        corz[l,:,:]=AZ.toarray()
        corx[l,:,:]=AX.toarray()
        cory[l,:,:]=AY.toarray()
        ccorz[l,:,:]=AAZ.toarray()
        ccorx[l,:,:]=AAX.toarray()
        ccory[l,:,:]=AAY.toarray()
    for l in range(N_2d):
        hfield0=[[1,l]]
        statfieldz=[["z",hfield0]]
        statfieldx=[["x",hfield0]]
        statfieldy=[["y",hfield0]]
        AZ=hamiltonian(statfieldz,[],basis=basis_spin,**no_checks)
        AX=hamiltonian(statfieldx,[],basis=basis_spin,**no_checks)
        AY=hamiltonian(statfieldy,[],basis=basis_spin,**no_checks)
        corz0[l,:,:]=AZ.toarray()
        corx0[l,:,:]=AX.toarray()
        cory0[l,:,:]=AY.toarray()    
elif N_2d == 9:
    h_fieldm1=[[1,0,1,2]] # remember to change this when the system size is varied
    static_spinm1 =[["zzz",h_fieldm1]] # static part of M
    h_fieldm2=[[1,0,3,6]] # remember to change this when the system size is varied
    static_spinm2 =[["xxx",h_fieldm2]] # static part of M
    corz0=np.zeros((N_2d,2**9,2**9),dtype=np.complex)
    corx0=np.zeros((N_2d,2**9,2**9),dtype=np.complex)
    cory0=np.zeros((N_2d,2**9,2**9),dtype=np.complex)
    corz=np.zeros((int(np.sqrt(N_2d)),2**9,2**9),dtype=np.complex)
    corx=np.zeros((int(np.sqrt(N_2d)),2**9,2**9),dtype=np.complex)
    cory=np.zeros((int(np.sqrt(N_2d)),2**9,2**9),dtype=np.complex)
    ccorz=np.zeros((int(np.sqrt(N_2d)),2**9,2**9),dtype=np.complex)
    ccorx=np.zeros((int(np.sqrt(N_2d)),2**9,2**9),dtype=np.complex)
    ccory=np.zeros((int(np.sqrt(N_2d)),2**9,2**9),dtype=np.complex)
    for l in range(int(np.sqrt(N_2d))):
        hfield=[[1,l*int(np.sqrt(N_2d)),l*int(np.sqrt(N_2d))+1,l*int(np.sqrt(N_2d))+2]]
        hfield2=[[1,l,l+int(np.sqrt(N_2d)),l+2*int(np.sqrt(N_2d))]]
        statfieldz=[["zzz",hfield]]
        statfieldx=[["xxx",hfield]]
        statfieldy=[["yyy",hfield]]
        sstatfieldz=[["zzz",hfield2]]
        sstatfieldx=[["xxx",hfield2]]
        sstatfieldy=[["yyy",hfield2]]
        AZ=hamiltonian(statfieldz,[],basis=basis_spin,**no_checks)
        AX=hamiltonian(statfieldx,[],basis=basis_spin,**no_checks)
        AY=hamiltonian(statfieldy,[],basis=basis_spin,**no_checks)
        AAZ=hamiltonian(sstatfieldz,[],basis=basis_spin,**no_checks)
        AAX=hamiltonian(sstatfieldx,[],basis=basis_spin,**no_checks)
        AAY=hamiltonian(sstatfieldy,[],basis=basis_spin,**no_checks)
        corz[l,:,:]=AZ.toarray()
        corx[l,:,:]=AX.toarray()
        cory[l,:,:]=AY.toarray()
        ccorz[l,:,:]=AAZ.toarray()
        ccorx[l,:,:]=AAX.toarray()
        ccory[l,:,:]=AAY.toarray()
    for l in range(N_2d):
        hfield0=[[1,l]]
        statfieldz=[["z",hfield0]]
        statfieldx=[["x",hfield0]]
        statfieldy=[["y",hfield0]]
        AZ=hamiltonian(statfieldz,[],basis=basis_spin,**no_checks)
        AX=hamiltonian(statfieldx,[],basis=basis_spin,**no_checks)
        AY=hamiltonian(statfieldy,[],basis=basis_spin,**no_checks)
        corz0[l,:,:]=AZ.toarray()
        corx0[l,:,:]=AX.toarray()
        cory0[l,:,:]=AY.toarray()

M1=hamiltonian(static_spinm1,[],basis=basis_spin,**no_checks) 
M2=hamiltonian(static_spinm2,[],basis=basis_spin,**no_checks) 


for dis in range(Nd):
    ######### Setting up Hamiltonian
    if N_2d == 4:
        SX1=[[1,0,1]]
        SX2=[[1,2,3]]
        sx1=hamiltonian([["xx",SX1]],[],basis=basis_spin,**no_checks)
        sx2=hamiltonian([["xx",SX2]],[],basis=basis_spin,**no_checks)
        JZZZZ = [[-ran.uniform(Jz1,Jz1+W),0,1,2,3]]
        JXXXXbound = [[-ran.uniform(Jx1,Jx1+W),0,1],[-ran.uniform(Jx1,Jx1+W),2,3]]
        h = [[ran.uniform(hx,hx+Whx),0],[ran.uniform(hx,hx+Whx),2]]
        hh = [[ran.uniform(hz,hz+Whz),0],[ran.uniform(hz,hz+Whz),1]]
        Hx = hamiltonian([["zzzz",JZZZZ],["xx",JXXXXbound]],[],basis=basis_spin,dtype=np.float64,**no_checks)
        Hh = hamiltonian([["x",h]],[],basis=basis_spin,**no_checks)
        Hhh = hamiltonian([["z",hh]],[],basis=basis_spin,**no_checks)
    elif N_2d == 9:
        SX1=[[1,0,1,2,3]]
        SX2=[[1,4,5,7,8]]
        SZ1=[[1,1,2,4,5]]
        SZ2=[[1,3,4,6,7]]
        SXb1=[[1,1,2]]
        SXb2=[[1,6,7]]
        SZb1=[[1,0,3]]
        SZb2=[[1,5,8]]
        sx1=hamiltonian([["xxxx",SX1]],[],basis=basis_spin,**no_checks)
        sx2=hamiltonian([["xxxx",SX2]],[],basis=basis_spin,**no_checks)
        sz1=hamiltonian([["zzzz",SZ1]],[],basis=basis_spin,**no_checks)
        sz2=hamiltonian([["zzzz",SZ2]],[],basis=basis_spin,**no_checks)
        sxb1=hamiltonian([["xx",SXb1]],[],basis=basis_spin,**no_checks)
        sxb2=hamiltonian([["xx",SXb2]],[],basis=basis_spin,**no_checks)
        szb1=hamiltonian([["zz",SZb1]],[],basis=basis_spin,**no_checks)
        szb2=hamiltonian([["zz",SZb2]],[],basis=basis_spin,**no_checks)
        JXXXX = [[-ran.uniform(Jx1,Jx1+W),0,1,3,4], [-ran.uniform(Jx1,Jx1+W),4,5,7,8]]
        JXXXXbound = [[-ran.uniform(Jx1,Jx1+W),1,2], [-ran.uniform(Jx1,Jx1+W),6,7]]
        JZZZZ = [[-ran.uniform(Jz1,Jz1+W),1,2,4,5], [-ran.uniform(Jz1,Jz1+W),3,4,6,7]]
        JZZZZbound = [[-ran.uniform(Jz1,Jz1+W),0,3], [-ran.uniform(Jz1,Jz1+W),5,8]]
        h = [[ran.uniform(hx,hx+Whx),0],[ran.uniform(hx,hx+Whx),3],[ran.uniform(hx,hx+Whx),6]]
        hh = [[ran.uniform(hz,hz+Whz),0],[ran.uniform(hz,hz+Whz),1],[ran.uniform(hz,hz+Whz),2]]
        Hx = hamiltonian([["zzzz",JZZZZ],["xxxx",JXXXX],["xx",JXXXXbound],["zz",JZZZZbound]],[],basis=basis_spin,dtype=np.float64,**no_checks)
        Hh = hamiltonian([["x",h]],[],basis=basis_spin,**no_checks)
        Hhh = hamiltonian([["z",hh]],[],basis=basis_spin,**no_checks)

    U1=la.expm(-1j*Hx.toarray())
    U2=la.expm(-1j*Hh.toarray())
    U3=la.expm(-1j*Hhh.toarray())

    U=np.dot(np.dot(U3,U2),U1)
    
    eigvals, eigvecs = la.eig(U)
    eigvals=np.angle(eigvals)
    Chiz0=0
    Chix0=0
    Chiy0=0
    Chiz=0
    Chix=0
    Chiy=0    
    CChiz=0
    CChix=0
    CChiy=0	

    for l in range(np.size(eigvals)):
        for ll in range(int(np.sqrt(N_2d))):
            for lll in range(int(np.sqrt(N_2d))):
                Chiz=Chiz+1/N_2d*np.abs(np.dot(np.dot(np.conj(np.transpose(eigvecs[:,l])),corz[lll,:,:]),np.dot(corz[ll,:,:],eigvecs[:,l])))**2
                Chix=Chix+1/N_2d*np.abs(np.dot(np.dot(np.conj(np.transpose(eigvecs[:,l])),corx[lll,:,:]),np.dot(corx[ll,:,:],eigvecs[:,l])))**2
                Chiy=Chiy+1/N_2d*np.abs(np.dot(np.dot(np.conj(np.transpose(eigvecs[:,l])),cory[lll,:,:]),np.dot(cory[ll,:,:],eigvecs[:,l])))**2
                CChiz=CChiz+1/N_2d*np.abs(np.dot(np.dot(np.conj(np.transpose(eigvecs[:,l])),ccorz[lll,:,:]),np.dot(ccorz[ll,:,:],eigvecs[:,l])))**2
                CChix=CChix+1/N_2d*np.abs(np.dot(np.dot(np.conj(np.transpose(eigvecs[:,l])),ccorx[lll,:,:]),np.dot(ccorx[ll,:,:],eigvecs[:,l])))**2
                CChiy=CChiy+1/N_2d*np.abs(np.dot(np.dot(np.conj(np.transpose(eigvecs[:,l])),ccory[lll,:,:]),np.dot(ccory[ll,:,:],eigvecs[:,l])))**2
        for ll in range(N_2d):
            for lll in range(N_2d):
                Chiz0=Chiz0+1/N_2d**2*np.abs(np.dot(np.dot(np.conj(np.transpose(eigvecs[:,l])),corz0[lll,:,:]),np.dot(corz0[ll,:,:],eigvecs[:,l])))**2
                Chix0=Chix0+1/N_2d**2*np.abs(np.dot(np.dot(np.conj(np.transpose(eigvecs[:,l])),corx0[lll,:,:]),np.dot(corx0[ll,:,:],eigvecs[:,l])))**2
                Chiy0=Chiy0+1/N_2d**2*np.abs(np.dot(np.dot(np.conj(np.transpose(eigvecs[:,l])),cory0[lll,:,:]),np.dot(cory0[ll,:,:],eigvecs[:,l])))**2
                
    Chiz=Chiz/np.size(eigvals)
    Chix=Chix/np.size(eigvals)
    Chiy=Chiy/np.size(eigvals)
    Chiz0=Chiz0/np.size(eigvals)
    Chix0=Chix0/np.size(eigvals)
    Chiy0=Chiy0/np.size(eigvals)
    CChiz=CChiz/np.size(eigvals)
    CChix=CChix/np.size(eigvals)
    CChiy=CChiy/np.size(eigvals)

    
    print(dis)

Chiz0=Chiz0/Nd
Chix0=Chix0/Nd
Chiy0=Chiy0/Nd
Chiz=Chiz/Nd
Chix=Chix/Nd
Chiy=Chiy/Nd
CChiz=CChiz/Nd
CChix=CChix/Nd
CChiy=CChiy/Nd    
    
    
    
    